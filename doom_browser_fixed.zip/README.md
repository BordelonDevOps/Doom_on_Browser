<img src="android-chrome-192x192.png" width="128px" height="128px">

# DOOM on JS-DOS
Play the classic "THE ULTIMATE DOOM" in your web browser today via JS-DOS.

## Special Note
Only works on Desktop/PC/Laptop/Mac environments. Does not work on mobile devices like Android, iOS, KaiOS and more.

## Play Now!
Visit https://bordelondevops.github.io/Doom_on_Browser/ to play!

## User Manual
You might want to know on how to play the game first before playing.<br>
Consider visiting https://github.com/BordelonDevOps/Doom_on_Browser/blob/main/MANUAL.MD first before playing.

## License
This software uses the MIT License. Please visit the link below to view the full license terms.<br>
https://github.com/BordelonDevOps/Doom_on_Browser/blob/main/LICENSE
